from fastapi import FastAPI
from trend_analyzer import get_trends, compare_trends

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Welcome to Trend Catchers API"}

@app.get("/trends")
def get_trend_data():
    return get_trends()

@app.get("/compare")
def compare():
    return compare_trends()
