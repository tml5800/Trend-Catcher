import React from "react";

const Dashboard = () => {
    return (
        <div>
            <h1>Trend Catchers Dashboard</h1>
            <input type="text" placeholder="Search Trends..." />
            <div>
                <h2>Current Trends</h2>
                {/* Map trends here */}
            </div>
        </div>
    );
};

export default Dashboard;